<h1>Wheel of fortune</h1>
<br/>
<p>Spin the wheel to win free prizes</p>
<br/>
<p>Rust casino wheel game, sort of</p>
<br/>
<a href="https://codmitu.github.io/spin-the-wheel/">Spin the Wheel game link</a>
<br/>
<br/>
<img src="https://github.com/codmitu/random-projects/blob/main/media-files/wheel.gif" alt="app image gif" /> 
<br/>
<img src="https://raw.githubusercontent.com/codmitu/random-projects/main/media-files/spin-the-wheel.jpg" alt="app image" /> 
